package Airplane;

import Airplane.Exception.*;

public class Airplane {

    //private boolean isMotorOn = false;
    //private boolean hasNotExploded = true;

    private double altitude = 0;
    private final double ALTITUDE_INCREMENT = 1000;
    private final double MAX_SAFE_ALTITUDE = 10000;
    private final double ALTITUDE_OF_EXPLOSION = 12000;

    private AirplaneState status = AirplaneState.ENGINE_OFF;


    //public boolean isMotorOn()
    //
    //   return isMotorOn;
    //


    public void startMotor() throws AirplaneExplodedException, MotorHasAlreadyStartedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (status == AirplaneState.ENGINE_OFF)  //isMotorOn == false
            status = AirplaneState.ENGINE_ON;
            //isMotorOn = true;

        else
            throw new MotorHasAlreadyStartedException("Motor has already started!");

    }


    public void stopMotor() throws AirplaneExplodedException, CannotStopFlyingAirplaneException, MotorHasAlreadyStoppedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (status == AirplaneState.ENGINE_ON)
            status = AirplaneState.ENGINE_OFF;

        else if (status == AirplaneState.FLYING)
            throw new CannotStopFlyingAirplaneException("You cannot stop an airplane that is flying!");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorHasAlreadyStoppedException("Motor has already been stopped!");

    }


    public void increaseAltitude() throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneNotInAirException ,AltitudeDangerException, AirplaneBoomException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("Cannot fly: Motor currently stopped!");

        else if (status == AirplaneState.ENGINE_ON)
            throw new AirplaneNotInAirException("Cannot increase altitude without taking off");
            //altitude += ALTITUDE_INCREMENT;
        else
            altitude += ALTITUDE_INCREMENT;

        //if(altitude <= MAX_SAFE_ALTITUDE)
        //DO NOTHING, ALL OK

        checkAltitude();

    }



    public void decreaseAltitude() throws AirplaneExplodedException, AirplaneAlreadyGroundedException, AltitudeDangerException, AirplaneBoomException {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (altitude == 0)
            throw new AirplaneAlreadyGroundedException("Cannot decrease altitude, airplane has already landed!");

        else if (status == AirplaneState.FLYING)
            altitude -= ALTITUDE_INCREMENT;

       checkAltitude();


    }

    public void takeOff () throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneAlreadyTookOffException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("Cannot take off! Please start the engine!");

        else if (status == AirplaneState.FLYING)
            throw new AirplaneAlreadyTookOffException("Airplane has already took off. You may want to increase altitude.");

        else if (status == AirplaneState.ENGINE_ON)
        {
            status = AirplaneState.FLYING;
            altitude += ALTITUDE_INCREMENT;
        }


    }


    public double getAltitude()
    {
        return this.altitude;
    }

    private void checkAltitude() throws AltitudeDangerException, AirplaneBoomException
    {

        if (getAltitude() >= MAX_SAFE_ALTITUDE && getAltitude() < ALTITUDE_OF_EXPLOSION)
            throw new AltitudeDangerException("Danger! Not a safe altitude! Maximum safe altitude is below: " + MAX_SAFE_ALTITUDE + " ft, current altitude: " + getAltitude() + " ft");

        else if (altitude == ALTITUDE_OF_EXPLOSION )
        {
            altitude = 0;
            status = AirplaneState.EXPLODED;
            //this.isMotorOn = false;
            //hasNotExploded = false;

            throw new AirplaneBoomException("BOOM!");
        }
        else if (altitude == 0)
        {
            status = AirplaneState.ENGINE_ON;
        }
    }

    private String engineState()
    {
        if (status == AirplaneState.ENGINE_OFF || status == AirplaneState.EXPLODED)
            return "Off";
        else if (status == AirplaneState.ENGINE_ON || status == AirplaneState.FLYING)
            return "On";
        return null;
    }

    private String airplaneCondition()
    {
        if (status == AirplaneState.EXPLODED)
            return "Exploded";
        else if (getAltitude() >= MAX_SAFE_ALTITUDE)
            return "Critical";
        return "Stable";

    }

    //public boolean isHasNotExploded()
    //{
    //    return hasNotExploded;
    //}

    public void airplaneBoard()
    {
        IO.println("Motor: " + engineState() + " \\ " + "Altitude: " + getAltitude() + " ft" + " \\ " + "Airplane's condition: " + airplaneCondition());

    }

}
