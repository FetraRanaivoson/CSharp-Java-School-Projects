package Airplane;

import java.util.function.Consumer;

public enum AirplaneState {

    ENGINE_OFF, ENGINE_ON, FLYING, EXPLODED;

}
