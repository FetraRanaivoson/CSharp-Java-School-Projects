package Airplane.Exception;

public class AltitudeDangerException extends  AirplaneException
{
    public AltitudeDangerException () {
        super();
    }
    public AltitudeDangerException (String message) {super (message);}
}
