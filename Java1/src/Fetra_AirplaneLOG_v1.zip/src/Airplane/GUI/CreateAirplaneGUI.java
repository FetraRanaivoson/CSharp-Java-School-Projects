package Airplane.GUI;

import javax.print.attribute.standard.JobMessageFromOperator;
import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;
import java.util.Date;


public class CreateAirplaneGUI extends JFrame {

    private JButton createNewAirplaneBtn;
    private JButton loadAirplaneBtn;
    private JPanel jPanel;
    private CreateFileLog createFileLog = new CreateFileLog();
    JTextField airplaneName = new JTextField();
    private Date date = new Date();
    private LocalTime time = LocalTime.now();
    private String airplane;
    private AirplaneGUIv2 airplaneGUIv2;


    public CreateAirplaneGUI()
    {
        //SET UP
        setTitle("Create Airplane");
        setSize(400,150);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        createComponents();
        setVisible(true);
    }

    public void createComponents()
    {
        //if create new airplane then create an unique log file
        //by specifying the name
        //if load an airplane then open the file browser


        add(jPanel = new JPanel());
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));
        jPanel.add(createNewAirplaneBtn = new JButton("Create New Airplane"));
        jPanel.add(loadAirplaneBtn = new JButton("Load Airplane"));
        createNewAirplaneBtn.setAlignmentX(CENTER_ALIGNMENT);
        loadAirplaneBtn.setAlignmentX(CENTER_ALIGNMENT);

        final JComponent[] inputs = new JComponent[] {
                new JLabel("Choose an airplane name"), airplaneName
        };

        createNewAirplaneBtn.addActionListener(e -> {
            this.airplane = (String) JOptionPane.showInputDialog(null,"Set up the airplane name", "myAirplane");
            createFileLog.createFile(airplane);
            //airplaneGUIv2 = new AirplaneGUIv2();
            createFileLog.recordAirplane("=============================================");
            createFileLog.recordAirplane("Airplane " + airplane + " logged in on " + date);
        });

        loadAirplaneBtn.addActionListener(e -> {

        });


    }

    public void createNewAirplaneLog (CreateFileLog createFileLog)
    {
        this.createFileLog = createFileLog;
    }

    public String getAirplaneName ()
    {
        return airplane;
    }
}
