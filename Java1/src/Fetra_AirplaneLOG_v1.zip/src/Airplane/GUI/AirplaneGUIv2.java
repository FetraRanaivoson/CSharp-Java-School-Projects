package Airplane.GUI;

import Airplane.Airplane;
import Airplane.Exception.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.time.LocalTime;
import java.util.Date;

public class AirplaneGUIv2 extends JFrame {

    //LOG FILE CONCERNS
    private CreateFileLog createFileLog = new CreateFileLog();
    private Date date = new Date();
    private LocalTime time = LocalTime.now();

    //AIRPLANE GUI PANELS CONCERNS
    private JPanel commandsPanel;
    private JPanel guiConsolePanel;
    private JPanel sliderPanel;
    private JTextArea consoleArea;

    //AIRPLANE GUI COMMANDS BUTTON CONCERNS
    public JButton startBtn;
    public JButton takeOffBtn;
    public JButton stopBtn;
    public JButton increaseAltitudeBtn;
    public JButton decreaseAltitudeBtn;
    public JButton exitBtn;

    //AIRPLANE GUI SLIDER CONCERNS
    private JLabel sliderLabel;
    private JSlider altitudeSlider;
    private Airplane airplane = new Airplane();
    private JButton clearConsoleBtn;
    private JTextArea generalInfosArea;

    //FILE > MenuItems
    private JMenuItem exitItem;
    private JMenuItem loadAirplaneItem;
    private JMenuItem readAirplaneItem;
    private JMenuItem newAirplaneItem;
    private JTextField textField;

    private CreateAirplaneGUI createAirplaneGUI;

    ///////CONSTRUCTOR STARTS//////////
    public AirplaneGUIv2 ()
    {
        createAirplaneGUI = new CreateAirplaneGUI();
        createAirplaneGUI.createNewAirplaneLog(createFileLog);
        //createFileLog();


        //SET UP
        setTitle("Airplane Controller" + "(" + createAirplaneGUI.getAirplaneName() + ")");
        setSize(800,600);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setJMenuBar(createMenuBar());

        //COMPONENTS STARTS
        createFileLog.createFile();
        createCommandsComponents(); //PANEL WEST: start/takeoff/stop/increase/decreaseAltitude
        createConsoleComponents(); //PANEL EAST: GUI console
        createAltitudeSliderCommands(); //PANEL SOUTH: slider
        //COMPONENTS ENDS
        repaint();
        revalidate();
        setVisible (true);
    }
    ///////CONSTRUCTOR ENDS/////////

    public void createCommandsComponents()
    {
        //ICONS
        ImageIcon icon = new ImageIcon("src/Airplane/img/blueprintResized.png");
        Icon takeOffIcon = new ImageIcon(getClass().getResource("takeOff.png"));
        Icon startIcon = new ImageIcon(getClass().getResource("engineGo.png"));
        Icon stopIcon = new ImageIcon(getClass().getResource("engineStop.png"));
        Icon increaseIcon = new ImageIcon(getClass().getResource("increase.png"));
        Icon decreaseIcon = new ImageIcon(getClass().getResource("decrease.png"));
        Icon landIcon = new ImageIcon(getClass().getResource("land.png"));
        ////////

        //SETUP
        add (commandsPanel = new JPanel(), BorderLayout.WEST);
        commandsPanel.setBorder(BorderFactory.createTitledBorder("Commands"));
        Dimension dimension = commandsPanel.getPreferredSize();
        dimension.width = 195;
        dimension.height = 375;
        commandsPanel.setPreferredSize(dimension);

        commandsPanel.setLayout(new GridLayout(3,2));
        commandsPanel.add(startBtn = new JButton("Start"));
        commandsPanel.add(takeOffBtn = new JButton("Take Off"));
        commandsPanel.add(stopBtn = new JButton("Stop"));
        commandsPanel.add(increaseAltitudeBtn = new JButton("Increase Alt"));
        commandsPanel.add(decreaseAltitudeBtn = new JButton("Decrease Alt"));
        commandsPanel.add(exitBtn = new JButton("Exit"));


        //LISTENERS
        Handler actionHandler = new Handler();
        startBtn.addActionListener(actionHandler);
        takeOffBtn.addActionListener(actionHandler);
        stopBtn.addActionListener(actionHandler);
        increaseAltitudeBtn.addActionListener(actionHandler);
        decreaseAltitudeBtn.addActionListener(actionHandler);
        exitBtn.addActionListener(actionHandler);


    }

    public void createConsoleComponents()
    {

        add(guiConsolePanel = new JPanel(), BorderLayout.CENTER);
        guiConsolePanel.setBorder(BorderFactory.createTitledBorder("Airplane Log"));

        File file = new File("src\\Airplane\\GUI\\bg.png");
        try {
            guiConsolePanel.add(consoleArea = new CustomJTextArea(file));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
//
        //Dimension dimension = consoleArea.getPreferredSize();
        //dimension.width = 550;
        //dimension.height = 375;
        //consoleArea.setPreferredSize(dimension);
        consoleArea.setSize(550,375);
        consoleArea.setRows(25);
        consoleArea.setLineWrap(true);
        consoleArea.setEditable(false);

        consoleArea.setBackground(Color.getHSBColor(80, 20, 33));
        consoleArea.setForeground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(consoleArea, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);

        guiConsolePanel.add(scroll);

        consoleArea.setText(airplane.airplaneBoard());

        repaint();
        revalidate();

    }

    public void createAltitudeSliderCommands()
    {
        //SETUP
        add (sliderPanel = new JPanel(), BorderLayout.SOUTH);

        sliderPanel.setBorder(BorderFactory.createTitledBorder("Altitude"));
        Dimension dimension = sliderPanel.getPreferredSize();
        dimension.height = 100;

        sliderPanel.setPreferredSize(dimension);

        sliderPanel.setLayout(new FlowLayout(0));
        sliderPanel.add(sliderLabel = new JLabel("Value"));

        sliderPanel.add(textField = new JTextField("               "));
        sliderPanel.add(new JLabel("ft"));

        sliderPanel.add(altitudeSlider = new JSlider(JSlider.HORIZONTAL, 0, 12000 , 0));
        altitudeSlider.setMajorTickSpacing(3000);
        altitudeSlider.setMinorTickSpacing(1500);
        altitudeSlider.setPaintTicks(true);
        altitudeSlider.setPaintLabels(true);
        //altitudeSlider.setMaximumSize(dimension);
        sliderPanel.add(clearConsoleBtn = new JButton("Clear console"));

        //General Informations about the airplane
        //sliderPanel.add(generalInfosArea = new JTextArea());
        //Dimension d = generalInfosArea.getPreferredSize();
        //dimension.width = 100;
        //dimension.height = 50;
        //generalInfosArea.setPreferredSize(dimension);
        //generalInfosArea.setLineWrap(true);


        //LISTENERS
        clearConsoleBtn.addActionListener(e -> {
            consoleArea.setText("");
            consoleArea.setText(airplane.airplaneBoard());
        });

        altitudeSlider.addChangeListener(new ChangeListener()
        {

            @Override
            public void stateChanged(ChangeEvent e)
            {
                consoleArea.setForeground(Color.WHITE);
                JSlider source = (JSlider)e.getSource();
                try {
                    airplane.setAltitude(source.getValue());
                    consoleArea.append(">>>" + LocalTime.now() + " : Altitude has increased, new altitude is: " + airplane.getAltitude() + "ft\n");
                    textField.setText(""+airplane.getAltitude());
                    //createFileLog.recordAirplane("\t" + time + " : Altitude has changed to: " + airplane.getAltitude() + "ft");

                } catch (AirplaneExplodedException | MotorIsNotStartedException | AirplaneNotInAirException | AltitudeDangerException | AirplaneBoomException |AirplaneAlreadyGroundedException exception) {
                    consoleArea.setForeground(Color.RED);
                    consoleArea.append(LocalTime.now()  + ": ERROR: " + exception.getMessage() + "\n");
                    System.err.println(exception.getMessage());
                }
                finally {
                    textField.setText(""+airplane.getAltitude());
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Altitude has changed to: " + airplane.getAltitude() + "ft");

                    if (airplane.getAltitude() > airplane.MAX_SAFE_ALTITUDE)
                        textField.setForeground(Color.red);
                    else
                        textField.setForeground(Color.black);
                }

            }

        });



    }

    private void createFileLog()
    {
        //createFileLog = new CreateFileLog();
       //createFileLog.createFile();
        //createFileLog.recordAirplane("=============================================");
        //createFileLog.recordAirplane("Default Airplane logged in on " + date);
        //Close file ???
    }


    private JMenuBar createMenuBar()
    {
        //SETUP
        JMenuBar menuBar = new JMenuBar();

        JMenu file = new JMenu("File");
        menuBar.add (file);

        file.add(newAirplaneItem = new JMenuItem("New Airplane"));
        file.add(loadAirplaneItem = new JMenuItem("Load Airplane..."));
        file.add(readAirplaneItem = new JMenuItem("Read current Airplane"));
        file.addSeparator();
        file.add(exitItem = new JMenuItem("Exit"));

        //LISTENERS
        newAirplaneItem.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                //Todo: CLEAR LOG OR CREATE A NEW AIRPLANE
                int userChoice = JOptionPane.showConfirmDialog(null, "Clear the airplane log file?", "Warning", 0);
                if (userChoice == JOptionPane.YES_OPTION)
                {
                    consoleArea.append("Log file cleared!\n");
                    createFileLog.clearAirplaneRecord();
                    JOptionPane.showMessageDialog(null, "Log successfully cleared!");
                    createFileLog.readAirplaneRecord();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
        readAirplaneItem.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                createFileLog.readAirplaneRecord();
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        exitItem.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                int userChoice = JOptionPane.showConfirmDialog(null,"Quit the application?", "Airplane controller", 0);
                if (userChoice == JOptionPane.YES_OPTION) {
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Airplane logged out");
                    createFileLog.recordAirplane("=============================================\n");
                    System.exit(0);
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });


        //Return JMenuBar
        return menuBar;
    }


    private class Handler implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try
            {
                consoleArea.setForeground(Color.WHITE);
                if (event.getSource() == startBtn)
                {
                    airplane.startMotor();
                    JOptionPane.showMessageDialog(getContentPane(), "Motor has started!");
                    IO.println("\tMotor has started!");
                    //airplane.airplaneBoard();
                    consoleArea.append(">>>" + LocalTime.now()  + " : Motor has started\n");
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Motor has started");

                }

                else if (event.getSource() == takeOffBtn)
                {
                    airplane.takeOff();
                    altitudeSlider.setValue((int)airplane.getAltitude());
                    //airplane.airplaneBoard();
                    consoleArea.append(">>>" + LocalTime.now()  + " : Airplane took off\n");
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Airplane took off");
                }

                else if (event.getSource() == stopBtn) {
                    airplane.stopMotor();
                    JOptionPane.showMessageDialog(getContentPane(), "Motor has stopped!");
                    IO.println("\tMotor has stopped!");
                    //airplane.airplaneBoard();
                    consoleArea.append(">>>" + LocalTime.now()  + " : Motor has stopped\n");
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Motor has stopped");
                }

                else if (event.getSource() == increaseAltitudeBtn)
                {
                    airplane.increaseAltitude();
                    altitudeSlider.setValue((int)airplane.getAltitude());
                    consoleArea.append(">>>" + LocalTime.now()  + " : Altitude has increased, new altitude is: " + airplane.getAltitude() + "ft\n");
                    createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Altitude has increased, new altitude is: " + airplane.getAltitude() + "ft");
                }

                else if (event.getSource() == decreaseAltitudeBtn)
                {
                    airplane.decreaseAltitude();
                    altitudeSlider.setValue((int)airplane.getAltitude());
                    consoleArea.append(">>>" + LocalTime.now()  + " : Altitude has decreased, new altitude is: " + airplane.getAltitude() + "ft\n");
                    createFileLog.recordAirplane("\t" + LocalTime.now()  +  " : Altitude has decreased, new altitude is: " + airplane.getAltitude() + "ft");
                    if (airplane.getAltitude() == 0)
                    {
                        IO.println("\tAirplane successfully landed on the ground.");
                        consoleArea.append(">>>" + LocalTime.now()  + " : Airplane landed, altitude is: " + airplane.getAltitude() + "ft\n");
                        createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Airplane landed, altitude is: " + airplane.getAltitude() + "ft");
                    }
                }

                else if (event.getSource() == exitBtn)
                {

                    int userChoice = JOptionPane.showConfirmDialog(null, "Quit the program?", "Warning", 0);
                    if (userChoice == JOptionPane.YES_OPTION) {
                        IO.println("------------------");
                        IO.println("\tAirplane application terminated.");
                        consoleArea.append("=============================================\n");
                        createFileLog.recordAirplane("\t" + LocalTime.now()  + " : Airplane logged out");
                        createFileLog.recordAirplane("=============================================\n");
                        System.exit(0);
                    }
                }
            }
            catch (AirplaneExplodedException | MotorHasAlreadyStartedException | MotorIsNotStartedException | AirplaneAlreadyTookOffException | CannotStopFlyingAirplaneException | MotorHasAlreadyStoppedException |AirplaneNotInAirException | AltitudeDangerException | AirplaneBoomException |AirplaneAlreadyGroundedException exception)
            {
                System.err.println(exception.getMessage());
                consoleArea.setForeground(Color.RED);
                consoleArea.append(LocalTime.now()  + ": ERROR: " + exception.getMessage() + "\n");
                createFileLog.recordAirplane("\t" + LocalTime.now()  + " ERROR: " + exception.getMessage());
            }
            finally {
                altitudeSlider.setValue((int)airplane.getAltitude());
            }
            //airplane.airplaneBoard();
        }

    }

}
