package Airplane.GUI;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;


public class CreateFileLog {

    private Formatter airplaneLogFile;
    private File file;
    private  FileWriter fileWriter;
    private PrintWriter printWriter;
    private Desktop desktop = Desktop.getDesktop();
    private boolean append = false;
    //private Scanner input = null;
    //private FileWriter fw = null;
    //ArrayList <String> racers = new ArrayList<String>();
    private String airplaneName;
    private CreateAirplaneGUI createAirplaneGUI;

    public void createFile()
    {
        try
        {
            //airplaneLogFile = new Formatter("src\\Airplane\\AirplaneLog.txt");
            file = new File("src\\Airplane\\SavedAirplane\\DefaultAirplaneLog.txt"); //Two ways to create a file
            //fileWriter = new FileWriter("NewLog.txt",true); //Two ways to create a file
        }
        catch (Exception e)
        {
            System.out.println("Error creating log file");
        }
    }

    public void createFile(String airplaneName)
    {
        try
        {
            //createAirplaneGUI.createNewAirplaneLog(this);
            //airplaneLogFile = new Formatter("src\\Airplane\\AirplaneLog.txt");
            file = new File("src\\Airplane\\SavedAirplane\\" + airplaneName +".txt"); //Two ways to create a file
            //fileWriter = new FileWriter("NewLog.txt",true); //Two ways to create a file
        }
        catch (Exception e)
        {
            System.out.println("Error creating log file");
        }
    }



    public void recordAirplane (String record)
    {
        //airplaneLogFile.format(record);
        try (PrintWriter out = new PrintWriter(new FileOutputStream(file, true))){;
            out.println(record);
        } catch (FileNotFoundException exception)
        {
            System.out.println("Error writing log file");
        }
    }

    public void recordAirplane(String record, boolean append)
    {
        try (PrintWriter out = new PrintWriter(new FileOutputStream(file, append))){;
            out.println(record);
    } catch (FileNotFoundException exception)
        {
            System.out.println("Error writing log file");
        }
    }

    public void clearAirplaneRecord ()
    {
        recordAirplane("",false);
    }

    public void readAirplaneRecord ()
    {
        try{
            if (!Desktop.isDesktopSupported())
            {
                System.out.println("Not supported");
                return;
            }
            if (file.exists())
                desktop.open(file);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }






/*
    public void openFile ()
    {
        try {
            input = new Scanner(file); //Open the file
            while (input.hasNextLine())
            {
                String nextRacer = input.nextLine();
                racers.add(nextRacer);//Add the racer
                System.out.println(nextRacer + " added..."); //Print out each racer added
            }
            if (input != null)
            {
                input.close();
                input = null;
            }
        }
        catch(IOException ioex) {
            ioex.printStackTrace();
        }

    }
*/

    public  void closeFile ()
    {

    }

}
