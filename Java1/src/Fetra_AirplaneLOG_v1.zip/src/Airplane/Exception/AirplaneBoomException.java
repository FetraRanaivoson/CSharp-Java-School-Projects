package Airplane.Exception;

public class AirplaneBoomException extends AirplaneException{
    public AirplaneBoomException () {
        super();
    }
    public AirplaneBoomException(String message) {super(message);}
}
