package Airplane.controller;

import Airplane.model.Airplane;
import Airplane.model.Exception.AirplaneExplodedException;
import Airplane.model.Exception.MotorHasAlreadyStartedException;
import Airplane.view.AirplaneGUIv2;

import java.util.ArrayList;

public class AirplaneController {

    private Airplane airplane = new Airplane();
    private AirplaneGUIv2 airplaneGUIv2;

    public AirplaneController (AirplaneGUIv2 airplaneGUIv2)
    {
        this.airplaneGUIv2 = airplaneGUIv2;
    }

    public void startAirplane() throws MotorHasAlreadyStartedException, AirplaneExplodedException
    {
        airplane.startMotor();
    }

}
