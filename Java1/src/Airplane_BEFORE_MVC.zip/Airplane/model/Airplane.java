package Airplane.model;

import Airplane.model.Exception.*;
import Airplane.view.AirplaneGUIv2;
import Airplane.view.AirplaneView;
import Airplane.view.CreateAirplaneGUI;

public class Airplane implements AirplaneView {

    //private boolean isMotorOn = false;
    //private boolean hasNotExploded = true;

    private double altitude = 0; //WHENEVER THE ALTITUDE CHANGES, NOTIFY THE GUI AT THIS MOMENT
    private final double ALTITUDE_INCREMENT = 1000;
    public final double MAX_SAFE_ALTITUDE = 10000;
    private final double ALTITUDE_OF_EXPLOSION = 12000;

    private AirplaneState status = AirplaneState.ENGINE_OFF;

    private AirplaneGUIv2 airplaneGuiv2;
    private CreateFileLog createFileLog ;

    private CreateAirplaneGUI createAirplaneGUI;

    //public boolean isMotorOn()
    //
    //   return isMotorOn;
    //

    public Airplane ()
    {

    }

    public Airplane (AirplaneGUIv2 airplaneGUIv2, CreateFileLog createFileLog)
    {
        this.airplaneGuiv2 = airplaneGUIv2;
        this.createFileLog = createFileLog;
        createFileLog.executeCommandsFromFile(airplaneGuiv2);
    }

    public void startMotor() throws AirplaneExplodedException, MotorHasAlreadyStartedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("start:failed:exploded");

        else if (status == AirplaneState.ENGINE_OFF)  //isMotorOn == false
            status = AirplaneState.ENGINE_ON;
            //isMotorOn = true;

        else
            throw new MotorHasAlreadyStartedException("start:failed:motorOn");

    }


    public void stopMotor() throws AirplaneExplodedException, CannotStopFlyingAirplaneException, MotorHasAlreadyStoppedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("stop:failed:exploded");

        else if (status == AirplaneState.ENGINE_ON)
            status = AirplaneState.ENGINE_OFF;

        else if (status == AirplaneState.FLYING)
            throw new CannotStopFlyingAirplaneException("stop:failed:flying");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorHasAlreadyStoppedException("stop:failed:motorOff");

    }

    //Notifier
    public void increaseAltitude() throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneNotInAirException ,AltitudeDangerException, AirplaneBoomException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("increase:failed");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("increase:failed:motorOff");

        else if (status == AirplaneState.ENGINE_ON)
            throw new AirplaneNotInAirException("increase:failed:notFlying");
            //altitude += ALTITUDE_INCREMENT;
        else {
            altitude += ALTITUDE_INCREMENT;
        }

        //if(altitude <= MAX_SAFE_ALTITUDE)
        //DO NOTHING, ALL OK


        checkAltitude();

    }



    //Notifier
    public void decreaseAltitude() throws AirplaneExplodedException, AirplaneAlreadyGroundedException, AltitudeDangerException, AirplaneBoomException {


        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("decrease::failed:exploded");

        else if (altitude == 0)
            throw new AirplaneAlreadyGroundedException("decrease:failed:landed");

        else if (status == AirplaneState.FLYING)
            altitude -= ALTITUDE_INCREMENT;


       checkAltitude();


    }



    public void takeOff () throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneAlreadyTookOffException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("takeoff:failed:exploded");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("takeoff:failed:motorOff");

        else if (status == AirplaneState.FLYING)
            throw new AirplaneAlreadyTookOffException("takeoff:failed:flying");

        else if (status == AirplaneState.ENGINE_ON)
        {
            status = AirplaneState.FLYING;
            altitude += ALTITUDE_INCREMENT;
        }


    }

    //Subscriber/Listener methods
    @Override
    public double getAltitude()
    {
        return this.altitude;
    }



    public void setAltitude(double altitude) //Subscriber/Listener methods
    {

            this.altitude = altitude;

        //checkAltitude();
    }

    public void setMotorOff()               //Subscriber/Listener methods
    {
        this.status = AirplaneState.ENGINE_OFF;
    }



    private void checkAltitude() throws AltitudeDangerException, AirplaneBoomException
    {


        if (getAltitude() >= MAX_SAFE_ALTITUDE && getAltitude() < ALTITUDE_OF_EXPLOSION) {
            throw new AltitudeDangerException("increase:danger:1000");
        }
        else if (altitude == ALTITUDE_OF_EXPLOSION )
        {
            altitude = 0;
            status = AirplaneState.EXPLODED;
            //this.isMotorOn = false;
            //hasNotExploded = false;

            throw new AirplaneBoomException("boom");
        }
        else if (altitude <= 0)
        {
            altitude = 0;
            status = AirplaneState.ENGINE_ON;
        }


    }

    @Override
    public String engineState()
    {
        if (status == AirplaneState.ENGINE_OFF || status == AirplaneState.EXPLODED)
            return "Off";
        else if (status == AirplaneState.ENGINE_ON || status == AirplaneState.FLYING)
            return "On";
        return null;
    }

    @Override
    public String airplaneCondition()
    {
        if (status == AirplaneState.EXPLODED)
            return "Exploded";
        else if (getAltitude() >= MAX_SAFE_ALTITUDE)
            return "Critical";
        return "Stable";

    }

    //public boolean isHasNotExploded()
    //{
    //    return hasNotExploded;
    //}

    @Override
    public String airplaneBoard()
    {
        return "Motor: " + engineState() + "  \\  " + "Altitude: " + getAltitude() + " ft" + "  \\  " + "Airplane's condition: " + airplaneCondition() + "\n";

    }



}
