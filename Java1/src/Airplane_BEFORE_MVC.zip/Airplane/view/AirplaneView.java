package Airplane.view;

import Airplane.model.Airplane;

public interface AirplaneView {

    String engineState();
    String airplaneCondition();
    String airplaneBoard();
    double getAltitude();


}
