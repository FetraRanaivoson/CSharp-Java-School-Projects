package Airplane.view;

import Airplane.model.AirplaneServer;

public interface InvolvedInAirplane {
    void setInvolved (AirplaneGUIv2 airplaneGUIv2, AirplaneServer airplaneServer);
}
