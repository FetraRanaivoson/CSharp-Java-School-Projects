package Airplane.view;

public interface AirplaneView {

    String engineState();
    String airplaneCondition();
    String airplaneBoard();
    double getAltitude();


}
