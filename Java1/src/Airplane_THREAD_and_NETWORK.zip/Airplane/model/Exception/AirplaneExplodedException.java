package Airplane.model.Exception;

public class AirplaneExplodedException extends AirplaneException
{
    public AirplaneExplodedException () {
        super();
    }
    public AirplaneExplodedException (String message)
    {
        super(message);
    }
}
