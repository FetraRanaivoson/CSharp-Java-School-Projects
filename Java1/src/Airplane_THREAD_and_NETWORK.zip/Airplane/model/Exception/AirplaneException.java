package Airplane.model.Exception;

public class AirplaneException extends Exception {

    public AirplaneException()
    {
        super();
    }

    public AirplaneException(String message)
    {
        super(message);
    }
}
