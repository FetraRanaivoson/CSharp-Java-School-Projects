package FinalExam.Model;

import FinalExam.Model.Exceptions.StopperAlreadyRemoved;
import FinalExam.Model.Exceptions.StopperNotPluggedException;
import FinalExam.Model.Exceptions.WaterAlreadyClosedException;
import FinalExam.Model.Exceptions.WaterAlreadyOpenException;
import FinalExam.View.BathControllerGUI;

import java.util.ArrayList;

public class BathModel {

    private float maxCapacity;
    private final float rateOfChange = maxCapacity * 0.1f;
    private float waterLevel = 0;
    private boolean isWaterClosed;
    private boolean isStopperPlugged;
    private ArrayList<BathObserver> observers = new ArrayList();


    public void addObservers (BathObserver observer)
    {
        observers.add(observer);
    }

    public BathModel ()
    {
        isWaterClosed = true;
        isStopperPlugged = true;
    }

    public void openWater () throws StopperNotPluggedException, WaterAlreadyOpenException
    {
        if (!isStopperPlugged)
            throw new StopperNotPluggedException("Cannot open water, stopper is not plugged");
        if (!isWaterClosed)
            throw new WaterAlreadyOpenException("Water is already open");
        else
            increaseWaterLevel();
    }

    public void closeWater () throws WaterAlreadyClosedException
    {
        if (isWaterClosed)
            throw new WaterAlreadyClosedException("Water is already closed");
        else if (!isWaterClosed)
            setWaterClosed(true);
    }

    public void removeStopper () throws StopperAlreadyRemoved, WaterAlreadyOpenException {
        if (!isStopperPlugged)
            throw new StopperAlreadyRemoved("Stopper is already removed");
        if (!isWaterClosed)
            throw new WaterAlreadyOpenException("Cannot remove stopper, water is open");
        else if (isStopperPlugged)
            decreaseWaterLevel();

    }

    public void setMaxCapacity (Float maxCapacity)
    {
        this.maxCapacity = maxCapacity;
    }

    public Float getMaxCapacity ()
    {
        return maxCapacity;
    }

    public float getWaterLevel()
    {
        return waterLevel;
    }


    public void setWaterLevel(Float waterLevel)
    {
        this.waterLevel = waterLevel;
    }

    public float increaseWaterLevel()
    {
        Thread increaseThread = new Thread( () -> {
                float currentLevel = getWaterLevel();
                float targetLevel = getMaxCapacity();

                do {
                    currentLevel += rateOfChange;
                    setWaterLevel(currentLevel);
                    notifyObservers();

                    try {
                        Thread.sleep(400);
                    } catch (InterruptedException exception) {
                        exception.printStackTrace();
                    }

                } while (currentLevel != targetLevel);
        });
        increaseThread.start();

        return waterLevel;
    }

    public float decreaseWaterLevel ()
    {
        Thread decreaseThread = new Thread( () -> {
            float currentLevel = getWaterLevel();
            float targetLevel = 0;

            do {
                currentLevel -= rateOfChange;
                setWaterLevel(currentLevel);
                notifyObservers();

                try {
                    Thread.sleep(400);
                } catch (InterruptedException exception) {
                    exception.printStackTrace();
                }

            } while (currentLevel != targetLevel);
        });
        decreaseThread.start();
        return waterLevel;
    }

    public void setWaterClosed (boolean waterClosed )
    {
        isWaterClosed = waterClosed;
    }

    public void setStopperPlugged (boolean stopperPlugged)
    {
        isStopperPlugged = stopperPlugged;
    }



    public String isWaterClosed ()
    {
        if (isWaterClosed)
            return "Closed";
        else
            return "Open";
    }

    public String isStopperPlugged ()
    {
        if (isStopperPlugged)
            return "Plugged";
        else
            return "Removed";
    }

    private void notifyObservers ()
    {
        for (BathObserver observer: observers)
        {
            observer.update(Math.round(getWaterLevel()));
        }
    }

    public String bathInfo ()
    {
        return "Water: " + isWaterClosed() + "\nStopper: " + isStopperPlugged();
    }

}
