package FinalExam.Model;

public interface BathObserver {
    void update (int waterLevel);
}
