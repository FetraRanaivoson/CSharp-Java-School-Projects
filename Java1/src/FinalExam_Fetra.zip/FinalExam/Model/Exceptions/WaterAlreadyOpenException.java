package FinalExam.Model.Exceptions;

public class WaterAlreadyOpenException extends BathException{

    public WaterAlreadyOpenException (String message) { super (message);}
}
