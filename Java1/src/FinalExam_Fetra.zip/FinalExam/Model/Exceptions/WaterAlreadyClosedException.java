package FinalExam.Model.Exceptions;

public class WaterAlreadyClosedException extends BathException {

    public WaterAlreadyClosedException (String message) { super (message);}
}
