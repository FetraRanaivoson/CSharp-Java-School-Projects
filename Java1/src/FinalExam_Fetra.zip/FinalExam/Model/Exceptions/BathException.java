package FinalExam.Model.Exceptions;

public class BathException extends Exception{

    public BathException ()
    {
        super ();
    }
    public BathException (String message)
    {
        super(message);
    }
}
