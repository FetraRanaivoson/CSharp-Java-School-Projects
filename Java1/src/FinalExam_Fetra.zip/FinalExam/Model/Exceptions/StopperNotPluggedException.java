package FinalExam.Model.Exceptions;

public class StopperNotPluggedException extends BathException{

    public StopperNotPluggedException (String message)
    {
        super (message);
    }

}
