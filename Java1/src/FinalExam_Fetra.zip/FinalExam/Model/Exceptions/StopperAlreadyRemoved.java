package FinalExam.Model.Exceptions;

public class StopperAlreadyRemoved extends BathException{

    public StopperAlreadyRemoved (String message) { super (message);}
}
