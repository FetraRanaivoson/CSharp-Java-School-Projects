package FinalExam.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BathMenuGUI extends JFrame {

    private JPanel bathMenuTop;
    private JPanel bathMenuBottom;
    private JButton newBtn;
    private JButton loadBtn;
    private JButton logBtn;
    private JProgressBar bathProgressBar;
    private JLabel bathPercentageLabel;

    public BathMenuGUI ()
    {
        setTitle("Bath Menu");
        setSize(500,150);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        createBathMenuComponents();
        setVisible(true);
    }

    public void createBathMenuComponents()
    {
        //MENU DESIGN
        add (bathMenuTop = new JPanel(), BorderLayout.NORTH);
        bathMenuTop.setBorder(BorderFactory.createTitledBorder("Menu"));
        bathMenuTop.add (newBtn = new JButton("New Bath"));
        bathMenuTop.add (loadBtn = new JButton("Load Bath"));
        bathMenuTop.add (logBtn = new JButton("Log Bath"));
        logBtn.setEnabled(false);
        logBtn.setToolTipText("Must create bath or create a new one.");

        add (bathMenuBottom = new JPanel(), BorderLayout.CENTER);
        bathMenuBottom.setBorder(BorderFactory.createTitledBorder("Current percentage"));

        //Todo : capacity of the bar in function to Bath capacity set (Listen to Bath model)
        bathMenuBottom.add (bathProgressBar = new JProgressBar(0,100));
        Dimension bathProgressBarDimension = bathProgressBar.getPreferredSize();
        bathProgressBarDimension.width = 300;
        bathProgressBar.setPreferredSize(bathProgressBarDimension);

        bathMenuBottom.add (bathPercentageLabel = new JLabel("0%"));

        //LISTENERS
        newBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CreateBathGUI();
            }
        });

        loadBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        logBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //todo: before showing log you must first start or load bath
            }
        });

    }

}
