package Airplane;

import Airplane.Exception.*;
import Airplane.GUI.AirplaneGUIv2;
import Airplane.GUI.CreateFileLog;

public class Airplane {

    //private boolean isMotorOn = false;
    //private boolean hasNotExploded = true;

    private double altitude = 0;
    private final double ALTITUDE_INCREMENT = 1000;
    public final double MAX_SAFE_ALTITUDE = 10000;
    private final double ALTITUDE_OF_EXPLOSION = 12000;

    private AirplaneState status = AirplaneState.ENGINE_OFF;

    private AirplaneGUIv2 airplaneGuiv2;
    private CreateFileLog createFileLog ;

    //public boolean isMotorOn()
    //
    //   return isMotorOn;
    //
public Airplane (AirplaneGUIv2 airplaneGUIv2, CreateFileLog createFileLog)
    {
        this.airplaneGuiv2 = airplaneGUIv2;
        this.createFileLog = createFileLog;
        createFileLog.executeCommandsFromFile(airplaneGuiv2);
    }

    public void startMotor() throws AirplaneExplodedException, MotorHasAlreadyStartedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("start:failed:exploded");

        else if (status == AirplaneState.ENGINE_OFF)  //isMotorOn == false
            status = AirplaneState.ENGINE_ON;
            //isMotorOn = true;

        else
            throw new MotorHasAlreadyStartedException("start:failed:motorOn");

    }


    public void stopMotor() throws AirplaneExplodedException, CannotStopFlyingAirplaneException, MotorHasAlreadyStoppedException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("stop:failed:exploded");

        else if (status == AirplaneState.ENGINE_ON)
            status = AirplaneState.ENGINE_OFF;

        else if (status == AirplaneState.FLYING)
            throw new CannotStopFlyingAirplaneException("stop:failed:flying");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorHasAlreadyStoppedException("stop:failed:motorOff");

    }


    public void increaseAltitude() throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneNotInAirException ,AltitudeDangerException, AirplaneBoomException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("increase:failed");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("increase:failed:motorOff");

        else if (status == AirplaneState.ENGINE_ON)
            throw new AirplaneNotInAirException("increase:failed:notFlying");
            //altitude += ALTITUDE_INCREMENT;
        else
            altitude += ALTITUDE_INCREMENT;

        //if(altitude <= MAX_SAFE_ALTITUDE)
        //DO NOTHING, ALL OK


        checkAltitude();

    }




    public void decreaseAltitude() throws AirplaneExplodedException, AirplaneAlreadyGroundedException, AltitudeDangerException, AirplaneBoomException {


        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("decrease::failed:exploded");

        else if (altitude == 0)
            throw new AirplaneAlreadyGroundedException("decrease:failed:landed");

        else if (status == AirplaneState.FLYING)
            altitude -= ALTITUDE_INCREMENT;


       checkAltitude();


    }



    public void takeOff () throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneAlreadyTookOffException
    {

        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("takeoff:failed:exploded");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("takeoff:failed:motorOff");

        else if (status == AirplaneState.FLYING)
            throw new AirplaneAlreadyTookOffException("takeoff:failed:flying");

        else if (status == AirplaneState.ENGINE_ON)
        {
            status = AirplaneState.FLYING;
            altitude += ALTITUDE_INCREMENT;
        }


    }


    public double getAltitude()
    {
        return this.altitude;
    }


    //For the GUI Slider
    public void setAltitude(double altitude) throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneNotInAirException ,AltitudeDangerException, AirplaneBoomException, AirplaneAlreadyGroundedException
    {
        if (status == AirplaneState.EXPLODED)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (status == AirplaneState.ENGINE_OFF)
            throw new MotorIsNotStartedException("Cannot fly: Motor currently stopped!");


        else if (status == AirplaneState.ENGINE_ON)
            throw new AirplaneNotInAirException("Cannot increase altitude without taking off");
            //altitude += ALTITUDE_INCREMENT;


        else
            this.altitude = altitude;

        if (altitude == 0) {
            status = AirplaneState.ENGINE_ON;
            throw new AirplaneAlreadyGroundedException("Cannot decrease altitude, airplane has already landed!");
        }


        //checkAltitude();
    }



    private void checkAltitude() throws AltitudeDangerException, AirplaneBoomException
    {


        if (getAltitude() >= MAX_SAFE_ALTITUDE && getAltitude() < ALTITUDE_OF_EXPLOSION) {
            throw new AltitudeDangerException("increase:danger:1000");
        }
        else if (altitude == ALTITUDE_OF_EXPLOSION )
        {
            altitude = 0;
            status = AirplaneState.EXPLODED;
            //this.isMotorOn = false;
            //hasNotExploded = false;

            throw new AirplaneBoomException("boom");
        }
        else if (altitude <= 0)
        {
            altitude = 0;
            status = AirplaneState.ENGINE_ON;
        }


    }

    public String engineState()
    {
        if (status == AirplaneState.ENGINE_OFF || status == AirplaneState.EXPLODED)
            return "Off";
        else if (status == AirplaneState.ENGINE_ON || status == AirplaneState.FLYING)
            return "On";
        return null;
    }

    private String airplaneCondition()
    {
        if (status == AirplaneState.EXPLODED)
            return "Exploded";
        else if (getAltitude() >= MAX_SAFE_ALTITUDE)
            return "Critical";
        return "Stable";

    }

    //public boolean isHasNotExploded()
    //{
    //    return hasNotExploded;
    //}

    public String airplaneBoard()
    {
        return "Motor: " + engineState() + "  \\  " + "Altitude: " + getAltitude() + " ft" + "  \\  " + "Airplane's condition: " + airplaneCondition() + "\n";

    }

}
