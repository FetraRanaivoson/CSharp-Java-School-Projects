package Airplane.Exception;

import Airplane.Airplane;

public class AirplaneExplodedException extends AirplaneException
{
    public AirplaneExplodedException () {
        super();
    }
    public AirplaneExplodedException (String message)
    {
        super(message);
    }
}
