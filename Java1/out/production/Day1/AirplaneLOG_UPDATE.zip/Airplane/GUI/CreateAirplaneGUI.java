package Airplane.GUI;

import javax.print.attribute.standard.JobMessageFromOperator;
import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;
import java.util.Date;


public class CreateAirplaneGUI extends JFrame {

    private JButton createNewAirplaneBtn;
    private JButton loadAirplaneBtn;
    private JPanel jPanel;
    private CreateFileLog createFileLog = new CreateFileLog();
    JTextField airplaneName = new JTextField();
    private Date date = new Date();
    private LocalTime time = LocalTime.now();
    private String airplane;
    private AirplaneGUIv2 airplaneGUIv2 ;
    private JTextArea consoleArea = new JTextArea();


    public CreateAirplaneGUI()
    {
        //SET UP
        setTitle("Create Airplane");
        setSize(400,150);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(HIDE_ON_CLOSE);
        createComponents();
        setVisible(false);
    }

    public void createComponents()
    {
        add(jPanel = new JPanel());
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));
        jPanel.add(createNewAirplaneBtn = new JButton("Create New Airplane"));
        jPanel.add(loadAirplaneBtn = new JButton("Load Airplane"));
        createNewAirplaneBtn.setAlignmentX(CENTER_ALIGNMENT);
        loadAirplaneBtn.setAlignmentX(CENTER_ALIGNMENT);

        final JComponent[] inputs = new JComponent[] {
                new JLabel("Choose an airplane name"), airplaneName
        };

        createNewAirplaneBtn.addActionListener(e -> {
            this.airplane = (String) JOptionPane.showInputDialog(null,"Set up the airplane name", "myAirplane");
            createFileLog.createFile(airplane);
            consoleArea.append("Airplane: " + airplane + " logged in on " + date + "\n" );
            consoleArea.append("=============================================\n");
            createFileLog.recordAirplane("=============================================");
            createFileLog.recordAirplane("Airplane " + airplane + " logged in on " + date);
            airplaneGUIv2.setTitle("Airplane Controller" + "(" + getAirplaneName(createFileLog) + ")");
            JOptionPane.showMessageDialog(null,getAirplaneName(createFileLog) + " successfully created.");
            this.setVisible(false);


        });

        loadAirplaneBtn.addActionListener(e -> {

        });


    }

    public void logInToAirplane (String airplaneName)
    {
        createFileLog.createFile(airplaneName);
        consoleArea.append("Airplane: " + airplaneName + " logged in on " + date + "\n" );
        consoleArea.append("=============================================\n");
        createFileLog.recordAirplane("=============================================");
        createFileLog.recordAirplane("Airplane " + airplaneName + " logged in on " + date);
        airplaneGUIv2.setTitle("Airplane Controller" + "(" + getAirplaneName(createFileLog) + ")");
    }

    public void createNewAirplaneLog (CreateFileLog createFileLog)
    {
        this.createFileLog = createFileLog;
    }

    public String getAirplaneName(CreateFileLog createFileLog)
    {
        return createFileLog.toString();
    }

    public void setTitle (AirplaneGUIv2 airplaneGUIv2)
    {
        this.airplaneGUIv2 = airplaneGUIv2;
    }

    public void setTextInConsole (JTextArea consoleArea)
    {
        this.consoleArea = consoleArea;
    }
}
