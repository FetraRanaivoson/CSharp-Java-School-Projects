package Airplane.Swing;
import Airplane.Airplane;
import Airplane.Exception.*;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.tools.Tool;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class AirplaneGUI extends JFrame {

    public JButton startBtn;
    public JButton takeOffBtn;
    public JButton stopBtn;
    public JButton increaseAltitudeBtn;
    public JButton decreaseAltitudeBtn;
    public JButton exitBtn;
    public JSlider altitudeSlider;
    public JTextArea textField;
    private Airplane airplane = new Airplane();


    public AirplaneGUI()
    {


        setTitle ("Airplane Controller");
        setSize(1174, 700);
        //setBounds(x,y,width,height); //Same as setSize and setLocation
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setJMenuBar(createMenuBar());

        setLayout(new FlowLayout(FlowLayout.CENTER, 20,20));
        //setLayout(new BoxLayout(getContentPane(), BoxLayout.X_AXIS));
        //setLayout(new BorderLayout());
        //setLayout(new GridLayout(3,3));
        //setLayout(new GridBagLayout());

        createComponents();

        setVisible(true);
    }

    private void createComponents()
    {
        ImageIcon icon = new ImageIcon("src/Airplane/img/blueprintResized.png");

        //Create and add the components


        add (startBtn = new JButton ("Start"));
        add (takeOffBtn = new JButton ("TakeOff"));
        add (stopBtn = new JButton ("Stop"));
        add (increaseAltitudeBtn = new JButton ("Increase altitude"));
        add (decreaseAltitudeBtn = new JButton ("Decrease altitude"));
        add (exitBtn = new JButton ("Exit"));
        //add (new JLabel("Infos"));
        //add (textField = new JTextArea(""));
        //textField.setColumns(20);

       // add (new JRadioButton("Motor On", false));
        add (new JLabel(icon));

        add (new JLabel ("Set Altitude:"));
        add (altitudeSlider = new JSlider(0,12000,0));


        //Slider and stuff
        altitudeSlider.createStandardLabels(1000);
        altitudeSlider.setMajorTickSpacing(6000);
        altitudeSlider.setMinorTickSpacing(3000);
        altitudeSlider.setPaintTicks(true);
        altitudeSlider.setPaintLabels(true);



        //Action listener: what to run when this button get clicked!
        //3 methods for action listener //

        /*
        ///1- Lambda method (Java 8+)
        startBtn.addActionListener(e -> {
            System.out.println("Motor has started in lambda method");

        });
        */
        /*
        startBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                    textField.append("Motor started");

            }
        });
*/

        /*
        ///2- Anonymous class (In our course curriculum)
        //Creating an object out of an interface
        startBtn.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //System.out.println("Motor has started in anonymous class");
                //takeOffBtn.setText("Wanna die?");
            }

        });
        */



        ///3- Method signature: method referencing (Java 8+)
        ///Whenever this button's clicked, call this method;
        //NOT LIKE THIS ONE:           startBtn.addActionListener(startMotor());
        ///----> We need to respect the method signature (parameters)
        startBtn.addActionListener(this::startMotor);
        takeOffBtn.addActionListener(this::takeOff);
        stopBtn.addActionListener(this::stopMotor);
        increaseAltitudeBtn.addActionListener(this::increaseAltitude);
        decreaseAltitudeBtn.addActionListener(this::decreaseAltitude);
        exitBtn.addActionListener(this::exitApp);

        altitudeSlider.addChangeListener(this::stateChanged);


    }

    public void startMotor(ActionEvent event)
    {
        try {
            airplane.startMotor();
            IO.println("\tMotor has started!");
        }
        catch (AirplaneExplodedException | MotorHasAlreadyStartedException exception)
        {
            System.err.println(exception.getMessage());
        }
        airplane.airplaneBoard();
    }

    public void takeOff (ActionEvent event)
    {
        try {
            airplane.takeOff();
        } catch (AirplaneExplodedException | MotorIsNotStartedException | AirplaneAlreadyTookOffException exception) {
            System.err.println(exception.getMessage());
        }
        airplane.airplaneBoard();
    }

    public void stopMotor (ActionEvent event)
    {
        try {
            airplane.stopMotor();
            JOptionPane.showMessageDialog(getContentPane(), "\tMotor has stopped!");
            IO.println("\tMotor has stopped!");
        }
        catch (AirplaneExplodedException | CannotStopFlyingAirplaneException | MotorHasAlreadyStoppedException exception)
        {
            System.err.println(exception.getMessage());
        }
        airplane.airplaneBoard();
    }

    public void increaseAltitude (ActionEvent event)
    {
        try {
            airplane.increaseAltitude();
            IO.println("\tAirplane's altitude: " + airplane.getAltitude() + " ft");
        }
        catch (AirplaneExplodedException | MotorIsNotStartedException | AirplaneNotInAirException | AltitudeDangerException | AirplaneBoomException exception)
        {
            System.err.println(exception.getMessage());
        }
        airplane.airplaneBoard();
    }

    public void decreaseAltitude (ActionEvent event)
    {
        try {
            airplane.decreaseAltitude();
            if (airplane.getAltitude() == 0)
                IO.println("\tAirplane successfully landed on the ground.");
            else if (airplane.getAltitude() != 0)
                IO.println("\tAirplane's altitude: " + airplane.getAltitude() + " ft");
        }
        catch (AirplaneExplodedException | AirplaneAlreadyGroundedException | AltitudeDangerException | AirplaneBoomException exception)
        {
            System.err.println(exception.getMessage());
        }
        airplane.airplaneBoard();
    }

    public int exitApp (ActionEvent event)
    {
        IO.println("------------------");
        IO.println("\tAirplane application terminated.");
        return 0;
    }

    private JMenuBar createMenuBar ()
    {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu ("File");
        JMenu windowMenu = new JMenu ("Window");

        JMenuItem exitApp = new JMenuItem("Exit");
        JMenuItem fullScreen = new JMenuItem("Full Screen");

        menuBar.add(fileMenu);
        menuBar.add(windowMenu);
        fileMenu.add(exitApp);
        windowMenu.add(fullScreen);



        return  menuBar;
    }

    public void stateChanged(ChangeEvent e)
    {
        JSlider source = (JSlider)e.getSource();
        if (!source.getValueIsAdjusting())
        {
            int altitude = source.getValue();
            if(altitude >= 10000)
                System.out.println("Danger!");

        }
    }
}


