package Airplane.controller;

import Airplane.model.Airplane;
import Airplane.model.Exception.*;
import Airplane.view.AirplaneGUIv2;
import Airplane.view.AirplaneView;

import java.util.ArrayList;

public class AirplaneController {

    private Airplane airplane ;
    private AirplaneGUIv2 airplaneGUIv2;


    public AirplaneController (AirplaneGUIv2 airplaneGUIv2, Airplane airplane)
    {
        this.airplaneGUIv2 = airplaneGUIv2;
        this.airplane = airplane;
    }

    public void startAirplane() throws MotorHasAlreadyStartedException, AirplaneExplodedException
    {
        airplane.startMotor();
    }

    public void setAltitude (double altitude)
    {

        airplane.setAltitude(altitude);
    }
    public void setMotorOff() //Listener/Subscriber //Notifier setDefaultAirplaneState (CreateAirplaneGui) should call this method
    {
        airplane.setMotorOff();

    }
    public void startMotor() throws MotorHasAlreadyStartedException, AirplaneExplodedException {
        airplane.startMotor();
    }

    public void stopMotor() throws MotorHasAlreadyStoppedException, AirplaneExplodedException, CannotStopFlyingAirplaneException {
        airplane.stopMotor();
    }

    public void takeOff() throws AirplaneExplodedException, AirplaneAlreadyTookOffException, MotorIsNotStartedException {
        airplane.takeOff();
    }

    public void increaseAltitude() throws AirplaneNotInAirException, MotorIsNotStartedException, AirplaneExplodedException, AltitudeDangerException, AirplaneBoomException {
        airplane.increaseAltitude();
    }

    public void decreaseAltitude() throws AirplaneBoomException, AirplaneExplodedException, AltitudeDangerException, AirplaneAlreadyGroundedException {
        airplane.decreaseAltitude();
    }
}
