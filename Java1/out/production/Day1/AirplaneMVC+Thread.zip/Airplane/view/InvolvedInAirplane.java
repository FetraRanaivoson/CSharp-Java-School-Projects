package Airplane.view;

import Airplane.model.Airplane;

public interface InvolvedInAirplane {
    void setInvolved (AirplaneGUIv2 airplaneGUIv2, Airplane airplane);
}
