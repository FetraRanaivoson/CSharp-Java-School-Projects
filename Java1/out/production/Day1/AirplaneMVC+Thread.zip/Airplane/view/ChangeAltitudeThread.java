package Airplane.view;


import Airplane.model.Airplane;

import javax.swing.*;

public class ChangeAltitudeThread implements Runnable
{

    private AirplaneGUIv2 airplaneGUIv2;
    private Airplane airplane;
    private int currentAltitude;
    private int targetAltitude;

    public ChangeAltitudeThread(Airplane airplane, AirplaneGUIv2 airplaneGUIv2)
    {
        this.airplane = airplane;
        this.airplaneGUIv2 = airplaneGUIv2;
    }

    @Override
    public void run()
    {
        if (airplaneGUIv2.increaseAltitudeBtn.isSelected())
            System.out.println("Hello");
        currentAltitude = (int)airplane.getAltitude();
        targetAltitude = currentAltitude + 1000;
        while (currentAltitude != targetAltitude)
        {
                currentAltitude++;
                //airplaneGUIv2.changeAltitude(currentAltitude);
                airplane.setAltitude(currentAltitude);
                airplaneGUIv2.appendTextToConsole(">>> : Altitude changed to : " + airplane.getAltitude());
                airplaneGUIv2.updateProgressBar((int)airplane.getAltitude());
                airplaneGUIv2.textArea.setText("                                                             " + airplane.airplaneBoard());
                try {
                    Thread.sleep(2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

        }
    }
}
