package Airplane.view;

public interface AltitudeObserver {
    void changeAltitude (int altitude);
}
