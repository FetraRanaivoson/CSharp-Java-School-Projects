package Airplane;

import java.util.function.Consumer;

public enum AirplaneState {

    ENGINE_OFF, ENGINE_ON, GROUNDED, FLYING, RIGHT_ALTITUDE, WRONG_ALTITUDE, GOOD, EXPLODED;


    public static boolean getAirplaneState (AirplaneState airplaneState)
    {
        
        switch (airplaneState)
        {
            case ENGINE_OFF:
                return true;

            case ENGINE_ON:
                return true;

            case GROUNDED:
                return true;

            case FLYING:
                return true;

            case RIGHT_ALTITUDE:
                return true;

            case WRONG_ALTITUDE:
                return  true;

            case GOOD:
                return true;

            case EXPLODED:
                if (airplaneState == )
                return true;

            default:
                return true;

        }
    }

}
