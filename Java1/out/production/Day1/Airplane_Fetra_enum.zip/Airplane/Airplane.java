package Airplane;

import Airplane.Exception.*;

public class Airplane {

    private boolean isMotorOn = false; //ENUM
    private double altitude = 0;
    private final double ALTITUDE_INCREMENT = 1000;
    private final double MAX_SAFE_ALTITUDE = 9999;
    private final double ALTITUDE_OF_EXPLOSION = 12000;
    private boolean hasNotExploded = true; //ENUM
    private AirplaneState airplaneState;


    public Airplane (AirplaneState engineState, AirplaneState groundedOrFlying, AirplaneState altitudeState, AirplaneState airplaneHealth)
    {
        this.airplaneState = engineState;
        this.airplaneState = groundedOrFlying;
        this.airplaneState = altitudeState;
        this.airplaneState = airplaneHealth;
    }

    public AirplaneState getAirplaneState ()
    {
        return airplaneState;
    }



    public boolean isMotorOn()
    {
        return isMotorOn;
    }


    public void startMotor() throws AirplaneExplodedException, MotorHasAlreadyStartedException
    {
        if(AirplaneState.getAirplaneState(AirplaneState.EXPLODED))
        //if(getAirplaneState()==AirplaneState.EXPLODED)
            //if (!hasNotExploded)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        if(AirplaneState.getAirplaneState(AirplaneState.ENGINE_OFF))
        //else if (getAirplaneState()==AirplaneState.ENGINE_OFF)
            this.airplaneState = AirplaneState.ENGINE_ON;
            //else if (isMotorOn == false)
            //isMotorOn = true;

        else
            throw new MotorHasAlreadyStartedException("Motor has already started!");

    }


    public void stopMotor() throws AirplaneExplodedException, CannotStopFlyingAirplaneException, MotorHasAlreadyStoppedException
    {

        if (!hasNotExploded )
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (isMotorOn == true && getAltitude() == 0)
            isMotorOn = false;

        else if (isMotorOn == true && getAltitude() > 0)
            throw new CannotStopFlyingAirplaneException("You cannot stop an airplane that is flying!");

        else
            throw new MotorHasAlreadyStoppedException("Motor has already been stopped!");

    }


    public void increaseAltitude() throws AirplaneExplodedException, MotorIsNotStartedException, AltitudeDangerException, AirplaneBoomException
    {

        if (!hasNotExploded)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (!isMotorOn)
            throw new MotorIsNotStartedException("Cannot fly: Motor currently stopped!");

        else if (isMotorOn)
            altitude += ALTITUDE_INCREMENT;

        //if(altitude <= MAX_SAFE_ALTITUDE)
        //DO NOTHING, ALL OK

        if (getAltitude() > MAX_SAFE_ALTITUDE && getAltitude() < ALTITUDE_OF_EXPLOSION)
            throw new AltitudeDangerException("Danger! Not a safe altitude! Maximum safe altitude is: " + MAX_SAFE_ALTITUDE + " ft, current altitude: " + getAltitude() + " ft");

        else if (altitude == ALTITUDE_OF_EXPLOSION )
        {
                altitude = 0;
                this.isMotorOn = false;
                hasNotExploded = false;
                throw new AirplaneBoomException("BOOM!");
        }

    }


    public void decreaseAltitude() throws AirplaneExplodedException, AirplaneAlreadyGroundedException, AltitudeDangerException
    {

        if (!hasNotExploded)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (altitude == 0)
            throw new AirplaneAlreadyGroundedException("Cannot decrease altitude, airplane is already grounded!");

        else if (altitude != 0)
            altitude -= ALTITUDE_INCREMENT;

        if (getAltitude() > MAX_SAFE_ALTITUDE && getAltitude() < ALTITUDE_OF_EXPLOSION)
            throw new AltitudeDangerException("Danger! Not a safe altitude! Maximum safe altitude is: " + MAX_SAFE_ALTITUDE + " ft, current altitude: " + getAltitude() + " ft");


    }

    public void takeOff () throws AirplaneExplodedException, MotorIsNotStartedException, AirplaneAlreadyTookOffException
    {

        if (!hasNotExploded)
            throw new AirplaneExplodedException("Sorry, the airplane has exploded!");

        else if (!isMotorOn)
            throw new MotorIsNotStartedException("Cannot take off! Please start the engine!");

        else if (getAltitude() != 0)
            throw new AirplaneAlreadyTookOffException("Airplane is already flying! Choose increase or decrease altitude, instead.");

        else
            altitude += ALTITUDE_INCREMENT;

    }

    public double getAltitude()
    {
        return this.altitude;
    }

    private String airplaneHealth()
    {
        if(AirplaneState.getAirplaneState(AirplaneState.EXPLODED))
        //if (!hasNotExploded)
            return "Exploded";
        else if (getAltitude() >= MAX_SAFE_ALTITUDE + 1)
            return "Wrong altitude";
        else
            return "Flying";

    }

    public boolean isHasNotExploded()
    {
        return hasNotExploded;
    }

    public void airplaneBoard()
    {
        IO.println("Motor ON: " + isMotorOn() + " \\ " + "Altitude: " + getAltitude() + " ft" + " \\ " + "Airplane status: " + airplaneHealth());

    }



}
