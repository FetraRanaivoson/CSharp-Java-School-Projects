package Airplane.Exception;

public class AirplaneAlreadyGroundedException extends Exception{
    public AirplaneAlreadyGroundedException (String message) {super(message);}
}
