package Airplane.Exception;

public class MotorHasAlreadyStartedException extends Exception
{
    public MotorHasAlreadyStartedException(String message) { super (message); }
}
