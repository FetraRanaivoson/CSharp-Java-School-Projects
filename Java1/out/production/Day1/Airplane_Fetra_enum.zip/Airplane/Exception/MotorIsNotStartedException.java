package Airplane.Exception;

public class MotorIsNotStartedException extends Exception{
    public MotorIsNotStartedException(String message) {super(message);}
}
