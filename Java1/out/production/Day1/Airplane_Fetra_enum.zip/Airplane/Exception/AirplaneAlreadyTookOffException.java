package Airplane.Exception;

public class AirplaneAlreadyTookOffException extends Exception{
    public AirplaneAlreadyTookOffException(String message) {super(message);}
}
