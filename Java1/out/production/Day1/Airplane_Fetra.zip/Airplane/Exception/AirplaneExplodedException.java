package Airplane.Exception;

import Airplane.Airplane;

public class AirplaneExplodedException extends Exception
{
    public AirplaneExplodedException (String message)
    {
        super(message);
    }
}
