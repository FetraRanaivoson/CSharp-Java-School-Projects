package Airplane.Exception;

public class MotorHasAlreadyStoppedException extends Exception {
    public MotorHasAlreadyStoppedException(String message) {super(message);}
}
