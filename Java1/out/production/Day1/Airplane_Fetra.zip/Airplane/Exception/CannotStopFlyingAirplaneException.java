package Airplane.Exception;

public class CannotStopFlyingAirplaneException extends Exception
{
    public CannotStopFlyingAirplaneException(String message) {super(message);}
}
