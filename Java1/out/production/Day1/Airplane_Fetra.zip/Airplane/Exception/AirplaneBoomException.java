package Airplane.Exception;

public class AirplaneBoomException extends Exception{
    public AirplaneBoomException(String message) {super(message);}
}
