package Airplane.Exception;

public class AltitudeDangerException extends  Exception
{
    public AltitudeDangerException (String message) {super (message);}
}
