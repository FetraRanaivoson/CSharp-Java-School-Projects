﻿//Author: Fetra Ranaivoson
using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingApp.ViewModels
{
    public class UpdateItemViewModel : CreateItemViewModel
    {
    }
}
