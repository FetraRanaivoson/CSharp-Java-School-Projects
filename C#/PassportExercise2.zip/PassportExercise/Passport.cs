﻿using System;
using System.Collections.Generic;
using System.Text;


namespace PassportExercise
{
    class Passport
    {
        public static int NextId = 0;

        //Automatic, manual properties
        public int Id {get;}
        public string FirstName {get;}
        public string LastName {get;}
        public DateTime DateOfBirth {get;}
        public Address Address {get;}
     
        public List<TravelRecord> TravelHistory{ get; set; }
        public bool Traveling {get; set;}
        public int TotalTimeTraveling { get; set; }


        //Calculated properties
        public string FullName 
        {
            get => FirstName + " " + LastName;
        }

        public int Age
        {
            get 
            {
                DateTime now = DateTime.UtcNow;
                TimeSpan age = now - DateOfBirth;
                return age.Days / 365 ;
            
            }
               
        }

        public TravelRecord CurrentLocation
        {
            get => TravelHistory[(TravelHistory.Count) - 1];
           
        }

        public DateTime TimeSinceLastTravel
        {
            get => CurrentLocation.TimeOfEntry;
          
        }




        public Passport (string firstName, string lastName, DateTime dateOfBirth, Address address)
        {
            Id = NextId ++;
            TravelHistory = new List<TravelRecord>()
            {
               
            };
            Traveling = false; 

            FirstName = firstName;
            LastName = lastName;
            DateOfBirth= dateOfBirth;
            Address = address;
        }

        public void Travel (string destinationCountry)
        {
            if (destinationCountry == Address.Country)
                Traveling = false;
            else
                Traveling = true;
            TravelRecord travelRecord = new TravelRecord(destinationCountry, DateTime.UtcNow);
            TravelHistory.Add(travelRecord);
            
        }

        public override string ToString()
        {
            return $"{"Id: " + Id} {FirstName} {LastName} { DateOfBirth} {Address}";
        }

    }
}
