﻿using System;

namespace PassportExercise
{
  


    class Program
    {
        static void Main()
        {
           
        }
    }
}
