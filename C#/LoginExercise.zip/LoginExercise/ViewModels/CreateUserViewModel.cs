﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LoginExercise.ViewModels
{
    public class CreateUserViewModel : ViewModel
    {
        private string username;
        public string Username
        {
            get => username;
            set
            {
                username = value;
                NotifyPropertyChanged(nameof(Username));
            }
        }

        private string password;
        public string Password
        {
            get => password;
            set
            {
                password = value;
                NotifyPropertyChanged(nameof(Password));
            }
        }

        public void ClearData()
        {
            Username = null;
            Password = null;
            
        }
    }
}
