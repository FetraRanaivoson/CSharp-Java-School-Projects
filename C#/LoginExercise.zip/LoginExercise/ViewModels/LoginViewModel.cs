﻿using LoginExercise.Repositories;
using LoginExercise.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Utility.ViewModels;

namespace LoginExercise.ViewModels
{
    public class LoginViewModel
    {
        public CreateUserViewModel CreateUserViewModel { get; }
        public DelegateCommand LogInCommand { get; }
        public DelegateCommand SignUpCommand { get; }

        public UserRepository UserRepository { get; set; }
        public UserService UserService { get; set; }
 
        public LoginViewModel ()
        {
            CreateUserViewModel = new CreateUserViewModel();
            UserRepository = new UserRepository();
            UserService = new UserService(UserRepository);
            LogInCommand = new DelegateCommand(LogIn);
            SignUpCommand = new DelegateCommand(SignUp);
        }

        private void LogIn (object _)
        {
            UserService.Login(CreateUserViewModel.Username, CreateUserViewModel.Password);
            CreateUserViewModel.ClearData();
        }

        private void SignUp (object _)
        {

        }
    }
}
