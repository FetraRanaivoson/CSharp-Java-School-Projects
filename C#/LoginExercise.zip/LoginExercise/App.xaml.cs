﻿using LoginExercise.Entities;
using LoginExercise.Repositories;
using LoginExercise.Views;
using System.Windows;
using Utility.Authentication;

namespace LoginExercise
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();

            //SignUp();


        }
        private void SignUp ()
        {
            /*

            //Check: does username already exist? If yes, error!

            //Else, if not
            string username = "admin";
            string password = "abc";

            PasswordHash passwordHash = PasswordUtility.GeneratePasswordHash(password);
            User user = new User(username, passwordHash);

            //Add a new User record to the database
            //Save Salt and Hash in that record
            UserRepository userRepository = new UserRepository();
            userRepository.Add(user);


            */
        }

        /*
        private bool Login (string username, string password)
        {
            /*


            //Check: Does username already exist?
            //If no, error!

            //Else, if yes:
            //Query database to get that user's Salt and Hash
            PasswordHash passwordHash = null;
            bool success = PasswordUtility.CheckPassword(password, passwordHash);

            return success;


          
        }
        */
    }
}
