﻿using Utility.Monads;
using LoginExercise.Repositories;
using Utility.Authentication;
using LoginExercise.Entities;
using System.Windows;

namespace LoginExercise.Services
{
    public interface IUserService
    {
        Result Login(string username, string password);
        Result SignUp(string username, string password);
        Result DeleteAccount(string username, string password);
    }

    public class UserService : IUserService
    {
        private readonly IUserRepository repository;

        public UserService(IUserRepository repository)
        {
            this.repository = repository;
        }

        public Result Login(string username, string password)
        {

            PasswordHash passwordHash = PasswordUtility.GeneratePasswordHash(password);
            User user = new User(username, passwordHash);
            repository.Add(user);

            return null;
        }

        public Result SignUp(string username, string password)
        {
            
            return null;
        }

        public Result DeleteAccount(string username, string password)
        {
            

            return null;
        }
    }
}
